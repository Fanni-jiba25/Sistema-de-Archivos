#!/bin/bash
javac Peer_G.java

java Peer_G 1 &
java Peer_G 2 &
java Peer_G 3 &
java Peer_G 4 &
java Peer_G 5 &
java Peer_G 6 &
